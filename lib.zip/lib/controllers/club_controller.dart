import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../models/club_lecture.dart';

class ClubController extends ChangeNotifier {
  final _db = FirebaseFirestore.instance;
  static const _col = 'clubs_lecture';
  static const _colMessages = 'messages_club';

  List<ClubLecture> _clubs = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<ClubLecture> get clubs => _clubs;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  // ─── Charger tous les clubs publics ──────────────────────────────────────
  Future<void> chargerClubs() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    try {
      debugPrint('🔵 Chargement des clubs publics...');
      final snap = await _db.collection(_col)
          .where('estPublic', isEqualTo: true)
          .orderBy('dateCreation', descending: true)
          .get();
      _clubs = snap.docs.map((d) => ClubLecture.fromFirestore(d)).toList();
      debugPrint('✅ ${_clubs.length} clubs chargés');
      for (var club in _clubs) {
        debugPrint('   - ${club.nom}: ${club.nbMembres} membres (${club.membresIds.join(", ")})');
      }
    } catch (e) {
      debugPrint('❌ Erreur chargement clubs: $e');
      // Si l'index n'est pas prêt, essayer sans orderBy
      if (e.toString().contains('index') || e.toString().contains('FAILED_PRECONDITION')) {
        debugPrint('⚠️ Tentative de chargement sans orderBy (index en cours de création)...');
        try {
          final snap = await _db.collection(_col)
              .where('estPublic', isEqualTo: true)
              .get();
          _clubs = snap.docs.map((d) => ClubLecture.fromFirestore(d)).toList();
          // Trier localement
          _clubs.sort((a, b) => b.dateCreation.compareTo(a.dateCreation));
          debugPrint('✅ ${_clubs.length} clubs chargés (tri local)');
        } catch (e2) {
          _errorMessage = 'Erreur de chargement: ${e2.toString()}';
          debugPrint('❌ Erreur chargement clubs (fallback): $e2');
        }
      } else {
        _errorMessage = 'Erreur de chargement: ${e.toString()}';
      }
    }
    _isLoading = false;
    notifyListeners();
  }

  /// Admin : tous les clubs (publics ou non)
  Future<void> chargerTousLesClubsAdmin() async {
    _isLoading = true;
    notifyListeners();
    try {
      final snap = await _db.collection(_col).get();
      _clubs = snap.docs.map((d) => ClubLecture.fromFirestore(d)).toList()
        ..sort((a, b) => b.dateCreation.compareTo(a.dateCreation));
    } catch (e) {
      _errorMessage = e.toString();
    }
    _isLoading = false;
    notifyListeners();
  }

  Future<bool> supprimerClub(String clubId) async {
    try {
      await _db.collection(_col).doc(clubId).delete();
      await chargerTousLesClubsAdmin();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  // ─── Créer un club ────────────────────────────────────────────────────────
  Future<bool> creerClub({
    required String nom,
    required String description,
    required String livreId,
    required String livreTitre,
    required String livreAuteur,
    required String createurId,
    required String createurNom,
    String livreCouverture = '',
    DateTime? dateLecture,
  }) async {
    try {
      debugPrint('🔵 Création du club "$nom"...');
      final club = ClubLecture(
        id: '',
        nom: nom,
        description: description,
        livreId: livreId,
        livreTitre: livreTitre,
        livreAuteur: livreAuteur,
        livreCouverture: livreCouverture,
        createurId: createurId,
        createurNom: createurNom,
        membresIds: [createurId],
        dateCreation: DateTime.now(),
        dateLecture: dateLecture,
      );
      await _db.collection(_col).add(club.toFirestore());
      debugPrint('✅ Club "$nom" créé avec succès');
      await chargerClubs();
      return true;
    } catch (e) {
      _errorMessage = 'Erreur lors de la création: ${e.toString()}';
      debugPrint('❌ Erreur création club: $e');
      notifyListeners();
      return false;
    }
  }

  // ─── Rejoindre / quitter un club ─────────────────────────────────────────
  Future<bool> rejoindre(String clubId, String membreId) async {
    try {
      debugPrint('🔵 Tentative de rejoindre le club $clubId par membre $membreId');
      
      // Vérifier que le club existe
      final clubDoc = await _db.collection(_col).doc(clubId).get();
      if (!clubDoc.exists) {
        _errorMessage = 'Club introuvable.';
        notifyListeners();
        debugPrint('❌ Club $clubId introuvable');
        return false;
      }
      
      // Vérifier si déjà membre
      final data = clubDoc.data() as Map<String, dynamic>;
      final membresIds = List<String>.from(data['membresIds'] ?? []);
      if (membresIds.contains(membreId)) {
        debugPrint('⚠️ Membre $membreId déjà dans le club $clubId');
        return true; // Déjà membre, considéré comme succès
      }
      
      // Ajouter le membre
      await _db.collection(_col).doc(clubId).update({
        'membresIds': FieldValue.arrayUnion([membreId]),
      });
      
      debugPrint('✅ Membre $membreId ajouté au club $clubId');
      await chargerClubs();
      return true;
    } catch (e) {
      _errorMessage = 'Erreur lors de l\'adhésion: ${e.toString()}';
      debugPrint('❌ Erreur rejoindre club: $e');
      notifyListeners();
      return false;
    }
  }

  Future<bool> quitter(String clubId, String membreId) async {
    try {
      final clubRef = _db.collection(_col).doc(clubId);
      final clubSnap = await clubRef.get();
      if (!clubSnap.exists) {
        _errorMessage = 'Club introuvable.';
        notifyListeners();
        return false;
      }

      final clubData = clubSnap.data() ?? <String, dynamic>{};
      final createurId = (clubData['createurId'] ?? '').toString();
      if (membreId == createurId) {
        _errorMessage = 'Le créateur ne peut pas quitter son club. Supprimez-le ou transférez la propriété.';
        notifyListeners();
        return false;
      }

      await _db.collection(_col).doc(clubId).update({
        'membresIds': FieldValue.arrayRemove([membreId]),
      });
      await chargerClubs();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  // ─── Messages du club (stream) ────────────────────────────────────────────
  Stream<QuerySnapshot> streamMessages(String clubId) {
    return _db
        .collection(_col)
        .doc(clubId)
        .collection(_colMessages)
        .orderBy('date', descending: false)
        .snapshots();
  }

  // ─── Envoyer un message ───────────────────────────────────────────────────
  Future<void> envoyerMessage({
    required String clubId,
    required String membreId,
    required String membreNom,
    required String contenu,
  }) async {
    await _db.collection(_col).doc(clubId).collection(_colMessages).add({
      'membreId': membreId,
      'membreNom': membreNom,
      'contenu': contenu,
      'date': FieldValue.serverTimestamp(),
    });
  }

  void clearError() { _errorMessage = null; notifyListeners(); }
}
