import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../controllers/auth_controller.dart';
import '../../controllers/club_controller.dart';
import '../../l10n/app_localizations.dart';
import '../../models/club_lecture.dart';
import '../../utils/constants.dart';
import '../../utils/helpers.dart';

class ClubDetailView extends StatefulWidget {
  final ClubLecture club;
  final bool fromAdminPanel;

  const ClubDetailView({
    super.key,
    required this.club,
    this.fromAdminPanel = false,
  });

  @override
  State<ClubDetailView> createState() => _ClubDetailViewState();
}

class _ClubDetailViewState extends State<ClubDetailView> with SingleTickerProviderStateMixin {
  final _msgCtrl = TextEditingController();
  late TabController _tabs;
  // Stream du club pour mise à jour temps réel du nombre de membres
  late Stream<DocumentSnapshot> _clubStream;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    _clubStream = FirebaseFirestore.instance
        .collection('clubs_lecture')
        .doc(widget.club.id)
        .snapshots();
  }

  @override
  void dispose() {
    _msgCtrl.dispose();
    _tabs.dispose();
    super.dispose();
  }

  void _apresActionMembre(bool ok, String messageSucces) {
    if (!mounted) return;
    if (ok) {
      if (messageSucces.isNotEmpty) AppHelpers.showSuccess(context, messageSucces);
      // Ne pas fermer la page, laisser l'utilisateur voir le changement
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final auth = context.watch<AuthController>();
    final ctrl = context.watch<ClubController>();
    final uid = auth.membre?.uid ?? '';

    return StreamBuilder<DocumentSnapshot>(
      stream: _clubStream,
      builder: (context, snap) {
        // Utiliser les données temps réel si disponibles, sinon fallback sur widget.club
        ClubLecture club = widget.club;
        if (snap.hasData && snap.data!.exists) {
          try {
            club = ClubLecture.fromFirestore(snap.data!);
          } catch (_) {}
        }

        final estMembre = club.estMembre(uid);
        final estCreateur = club.createurId == uid;

        return _buildScaffold(context, l10n, auth, ctrl, club, uid, estMembre, estCreateur);
      },
    );
  }

  Widget _buildScaffold(BuildContext context, dynamic l10n, AuthController auth,
      ClubController ctrl, ClubLecture club, String uid, bool estMembre, bool estCreateur) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(club.nom, maxLines: 1, overflow: TextOverflow.ellipsis),
        backgroundColor: AppColors.primaryDark,
        foregroundColor: Colors.white,
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: AppColors.accentLight,
          labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
          tabs: [
            Tab(text: l10n.clubTabChat, icon: const Icon(Icons.chat_rounded, size: 18)),
            Tab(text: l10n.clubTabAbout, icon: const Icon(Icons.info_outline_rounded, size: 18)),
          ],
        ),
        actions: [
          if (auth.isAuthenticated)
            Padding(
              padding: const EdgeInsets.only(right: 4),
              child: TextButton(
                onPressed: (estMembre && estCreateur)
                    ? null
                    : () async {
                  bool ok;
                  if (estMembre) {
                    ok = await ctrl.quitter(club.id, uid);
                    if (widget.fromAdminPanel) {
                      if (ok && mounted) {
                        AppHelpers.showInfo(context, 'Vous avez quitté le club.');
                        await ctrl.chargerTousLesClubsAdmin();
                      } else if (!ok && mounted) {
                        AppHelpers.showError(context, ctrl.errorMessage ?? 'Erreur lors de la sortie du club.');
                      }
                    } else {
                      if (!ok && mounted) {
                        AppHelpers.showError(context, ctrl.errorMessage ?? 'Erreur lors de la sortie du club.');
                      } else {
                        _apresActionMembre(ok, '');
                      }
                    }
                  } else {
                    ok = await ctrl.rejoindre(club.id, uid);
                    if (widget.fromAdminPanel) {
                      if (ok && mounted) {
                        AppHelpers.showSuccess(context, l10n.clubJoin);
                        await ctrl.chargerTousLesClubsAdmin();
                      } else if (!ok && mounted) {
                        AppHelpers.showError(context, ctrl.errorMessage ?? 'Erreur lors de l\'adhésion au club.');
                      }
                    } else {
                      if (!ok && mounted) {
                        AppHelpers.showError(context, ctrl.errorMessage ?? 'Erreur lors de l\'adhésion au club.');
                      } else {
                        _apresActionMembre(ok, l10n.clubJoin);
                      }
                    }
                  }
                },
                child: Text(
                  (estMembre && estCreateur)
                      ? 'Créateur'
                      : (estMembre ? l10n.clubLeave : l10n.clubJoin),
                  style: TextStyle(
                    color: (estMembre && estCreateur)
                        ? Colors.white54
                        : (estMembre ? AppColors.accentLight : Colors.white),
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          _DiscussionTab(
            club: club,
            uid: uid,
            estMembre: estMembre,
            auth: auth,
            msgCtrl: _msgCtrl,
            fromAdminPanel: widget.fromAdminPanel,
          ),
          _AboutTab(club: club, estCreateur: estCreateur),
        ],
      ),
    );
  }
}

class _DiscussionTab extends StatelessWidget {
  final ClubLecture club;
  final String uid;
  final bool estMembre;
  final AuthController auth;
  final TextEditingController msgCtrl;
  final bool fromAdminPanel;

  const _DiscussionTab({
    required this.club,
    required this.uid,
    required this.estMembre,
    required this.auth,
    required this.msgCtrl,
    required this.fromAdminPanel,
  });

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final ctrl = context.read<ClubController>();

    return Column(
      children: [
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: ctrl.streamMessages(club.id),
            builder: (_, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;
              if (docs.isEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: AppColors.accentSoft,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.forum_rounded, size: 40, color: AppColors.accentDark),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Première discussion',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                            color: Theme.of(context).colorScheme.onSurface,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Partagez vos impressions sur le livre du club.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, height: 1.4),
                        ),
                      ],
                    ),
                  ),
                );
              }
              return ListView.builder(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                itemCount: docs.length,
                itemBuilder: (_, i) {
                  final data = docs[i].data() as Map<String, dynamic>;
                  final isMe = data['membreId'] == uid;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(
                      mainAxisAlignment: isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
                      children: [
                        Flexible(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                            decoration: BoxDecoration(
                              gradient: isMe ? AppColors.gradientCard : null,
                              color: isMe ? null : Theme.of(context).colorScheme.surfaceContainerHighest,
                              borderRadius: BorderRadius.only(
                                topLeft: const Radius.circular(18),
                                topRight: const Radius.circular(18),
                                bottomLeft: Radius.circular(isMe ? 18 : 4),
                                bottomRight: Radius.circular(isMe ? 4 : 18),
                              ),
                              boxShadow: isMe ? AppUI.softShadow : null,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (!isMe)
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 4),
                                    child: Text(
                                      data['membreNom'] ?? '',
                                      style: const TextStyle(
                                        fontSize: 11,
                                        color: AppColors.accentLight,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                  ),
                                Text(
                                  data['contenu'] ?? '',
                                  style: TextStyle(
                                    fontSize: 14,
                                    height: 1.35,
                                    color: isMe ? Colors.white : Theme.of(context).colorScheme.onSurface,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
        if (estMembre)
          Container(
            padding: EdgeInsets.fromLTRB(12, 8, 12, 8 + MediaQuery.of(context).padding.bottom),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.06),
                  blurRadius: 12,
                  offset: const Offset(0, -4),
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: msgCtrl,
                    minLines: 1,
                    maxLines: 4,
                    decoration: AppInputDecoration.standard(
                      label: 'Message',
                      icon: Icons.chat_outlined,
                    ).copyWith(
                      hintText: l10n.clubMessageHint,
                      fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: const BorderSide(color: AppColors.primary, width: 2),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Material(
                  color: AppColors.accent,
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () async {
                      if (msgCtrl.text.trim().isEmpty) return;
                      await ctrl.envoyerMessage(
                        clubId: club.id,
                        membreId: uid,
                        membreNom: auth.membre!.nomComplet,
                        contenu: msgCtrl.text.trim(),
                      );
                      msgCtrl.clear();
                    },
                    child: const Padding(
                      padding: EdgeInsets.all(12),
                      child: Icon(Icons.send_rounded, color: Colors.white, size: 22),
                    ),
                  ),
                ),
              ],
            ),
          )
        else if (auth.isAuthenticated)
          Container(
            width: double.infinity,
            padding: EdgeInsets.fromLTRB(12, 10, 12, 12 + MediaQuery.of(context).padding.bottom),
            color: Theme.of(context).colorScheme.surface,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.primary.withValues(alpha: 0.08), AppColors.accent.withValues(alpha: 0.12)],
                ),
                borderRadius: BorderRadius.circular(AppSizes.radius),
                border: Border.all(color: AppColors.primary.withValues(alpha: 0.2)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      l10n.clubJoinToChat,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    ),
                    const SizedBox(height: 10),
                    FilledButton.icon(
                      onPressed: () async {
                        final ok = await ctrl.rejoindre(club.id, uid);
                        if (context.mounted) {
                          if (ok) {
                            AppHelpers.showSuccess(context, l10n.clubJoin);
                            if (fromAdminPanel) await ctrl.chargerTousLesClubsAdmin();
                          } else {
                            AppHelpers.showError(context, ctrl.errorMessage ?? 'Erreur lors de l\'adhésion au club.');
                          }
                        }
                      },
                      icon: const Icon(Icons.group_add_rounded),
                      label: Text(l10n.clubJoin),
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _AboutTab extends StatelessWidget {
  final ClubLecture club;
  final bool estCreateur;

  const _AboutTab({required this.club, required this.estCreateur});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: AppColors.gradientWarm,
            borderRadius: BorderRadius.circular(AppSizes.radiusLarge),
            boxShadow: AppUI.cardShadow,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Livre du club', style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              Text(
                club.livreTitre,
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
              ),
              Text(
                club.livreAuteur,
                style: TextStyle(color: Colors.white.withValues(alpha: 0.85), fontSize: 14),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Text(
          'À propos',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w800,
            color: AppColors.primary,
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          club.description.isEmpty ? 'Pas de description.' : club.description,
          style: TextStyle(height: 1.45, color: Theme.of(context).colorScheme.onSurface),
        ),
        const SizedBox(height: 20),
        _MetaRow(icon: Icons.person_outline_rounded, label: 'Créé par', value: club.createurNom),
        const SizedBox(height: 10),
        _MetaRow(
          icon: Icons.people_alt_outlined,
          label: 'Membres',
          value: '${club.nbMembres}',
        ),
        if (estCreateur) ...[
          const SizedBox(height: 16),
          AppUI.badge('Vous êtes l’organisateur', AppColors.accentDark),
        ],
      ],
    );
  }
}

class _MetaRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _MetaRow({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 20, color: AppColors.accent),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant)),
              Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            ],
          ),
        ),
      ],
    );
  }
}
